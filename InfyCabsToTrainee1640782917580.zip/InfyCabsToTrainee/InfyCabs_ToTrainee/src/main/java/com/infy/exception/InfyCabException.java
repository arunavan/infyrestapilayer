package com.infy.exception;

public class InfyCabException extends Exception {
	private static final long serialVersionUID = 1L;

	public InfyCabException(String message) {
		super(message);
	}
}

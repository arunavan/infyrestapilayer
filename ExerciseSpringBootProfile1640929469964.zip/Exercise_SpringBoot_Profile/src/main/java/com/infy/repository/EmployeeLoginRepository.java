package com.infy.repository;

import com.infy.dto.EmployeeLogin;

public interface EmployeeLoginRepository {
	public EmployeeLogin getEmployeeLoginByLoginName(String loginName);
}

package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.EmployeeLogin;
import com.infy.exception.EmployeeAuthenticateException;
import com.infy.repository.EmployeeLoginRepository;
@Service(value="employeeLoginService")
public class EmployeeLoginServiceImpl implements EmployeeLoginService {

	@Autowired
	private EmployeeLoginRepository employeeLoginRepository;

	public String authenticateCustomer(EmployeeLogin employeeLogin) throws EmployeeAuthenticateException {
		
			String toRet = null;
			EmployeeLogin customerLoginFromDao = employeeLoginRepository
					.getEmployeeLoginByLoginName(employeeLogin.getLoginName());
			if (employeeLogin.getPassword().equals(customerLoginFromDao.getPassword())){
				toRet = "SUCCESS";
			}else{
				throw new EmployeeAuthenticateException("Service.WRONG_CREDENTIALS");
			}
			return toRet;
		
	}
}

package com.infy.service;

import com.infy.dto.EmployeeLogin;
import com.infy.exception.EmployeeAuthenticateException;

public interface EmployeeLoginService {
	public String authenticateCustomer(EmployeeLogin employeeLogin)
			throws EmployeeAuthenticateException;
}

package com.infy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoRestTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}

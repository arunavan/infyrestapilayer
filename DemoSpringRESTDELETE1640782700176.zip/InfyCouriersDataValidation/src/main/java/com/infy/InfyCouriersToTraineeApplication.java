package com.infy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfyCouriersToTraineeApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfyCouriersToTraineeApplication.class, args);
	}

}

package com.infy.infyinterns.repository;

public interface MentorRepository
{
    // add methods if required
}

package com.infy.infyinterns.repository;

public interface ProjectRepository
{

    // add methods if required

}

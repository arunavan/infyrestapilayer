package com.infy.service;

import com.infy.dao.CustomerLoginDAO;
import com.infy.dao.CustomerLoginDAOImpl;
import com.infy.model.CustomerLogin;

public class CustomerLoginServiceImpl implements CustomerLoginService {

	private CustomerLoginDAO customerLoginDao;

	public String authenticateCustomer(CustomerLogin customerLogin) {
		String toRet = null;
		customerLoginDao = new CustomerLoginDAOImpl();
		
		CustomerLogin customerLoginFromDao = customerLoginDao
				.getCustomerLoginByLoginName(customerLogin.getLoginName());
		if (customerLogin.getPassword().equals(
				customerLoginFromDao.getPassword())) {
			toRet = "success";
		} else {
			toRet = "failed";
		}
		return toRet;
	}
}

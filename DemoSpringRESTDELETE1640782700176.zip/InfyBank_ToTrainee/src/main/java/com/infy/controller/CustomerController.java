package com.infy.controller;


import org.springframework.web.servlet.ModelAndView;

public class CustomerController {

	
	
	
	
	
	public ModelAndView getCustomerByStatus(String customerStatus) throws Exception{
		
		return null;
	}
	
	
	public ModelAndView getAllCustomerDetails() throws Exception{
		return null;
	}
}

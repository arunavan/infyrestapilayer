package com.infy.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dao.CustomerDAO;
import com.infy.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDAO customerDao;

	@Override
	public List<Customer> getAllCustomer() {
		return customerDao.getAllCustomer();
	}

	@Override
	public List<Customer> getCustomerByStatus(String customerStatus) {
		List<Customer> customerListFromDAO=customerDao.getAllCustomer();
		 List<Customer> toRet=new ArrayList<Customer>();
		 
		 customerListFromDAO.forEach(c->{
			 if(c.getStatus().equalsIgnoreCase(customerStatus)){
				 toRet.add(c);
			 }
		 });
		 
		 
		return toRet;
	}

	
}
